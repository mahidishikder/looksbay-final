"use client";

import React from "react";
import { Sparkles } from "lucide-react";

/**
 * 🛠️ Services Component 1: Hero Header
 * Title, badge, and intro for services and industry verticals
 */
export default function Services1_Hero() {
  return (
    <section className="text-center max-w-4xl mx-auto space-y-6">
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-100 border border-purple-200 text-purple-900 text-xs font-bold shadow-xs">
        <Sparkles className="w-3.5 h-3.5 text-purple-700" />
        <span>10 Industry Verticals · 5+ Live Verified Builds Per Category</span>
      </div>

      <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-[#1E0D36] tracking-tight leading-[1.05]">
        Engineered Platforms for <br />
        <span className="bg-gradient-to-r from-[#7C3AED] via-[#9333EA] to-[#4F46E5] bg-clip-text text-transparent">
          Ambitious Market Leaders.
        </span>
      </h1>

      <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed font-medium">
        Select your industry to explore curated case studies, technical frameworks, and verified business growth metrics. Every project is backed by our 95+ PageSpeed guarantee.
      </p>
    </section>
  );
}
