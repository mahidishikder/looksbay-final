"use client";

import React from "react";
import { Users } from "lucide-react";

/**
 * 👥 About Component 1: Hero Header
 * Headline, badge & intro for LooksBay's 20-person in-house collective
 */
export default function About1_Hero() {
  return (
    <section className="text-center max-w-4xl mx-auto space-y-6">
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-100 border border-purple-200 text-purple-900 text-xs font-bold shadow-xs">
        <Users className="w-3.5 h-3.5 text-purple-700" />
        <span>20-Person Dedicated In-House Production Collective</span>
      </div>

      <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-[#1E0D36] tracking-tight leading-[1.05]">
        Engineering Digital Flagships <br />
        <span className="bg-gradient-to-r from-[#7C3AED] via-[#9333EA] to-[#4F46E5] bg-clip-text text-transparent">
          With Zero Outsourced Fluff.
        </span>
      </h1>

      <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed font-medium">
        We are not a bloated legacy agency with layers of junior account managers. We are a tightly knit collective of 20 senior CMS developers, motion designers, and SEO auditors who live and breathe high performance.
      </p>
    </section>
  );
}
