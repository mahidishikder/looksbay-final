"use client";

import React from "react";
import { Trophy, Layers } from "lucide-react";
import { workProjectsList } from "./Work2_StackedCards";

export const workCategories = ["All", "Webflow", "Shopify Plus", "Framer", "WordPress"];

interface Work1_HeaderFilterProps {
  activeCategory: string;
  onSelectCategory: (category: string) => void;
}

/**
 * 💼 Work Component 1: Header & Category Filter
 * Hero title, subtitle, and dynamic category pill buttons
 */
export default function Work1_HeaderFilter({
  activeCategory,
  onSelectCategory,
}: Work1_HeaderFilterProps) {
  return (
    <section className="text-center max-w-4xl mx-auto space-y-6 mb-16">
      {/* Top Pill */}
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-100/90 border border-purple-200 text-purple-900 text-xs font-black shadow-xs">
        <Trophy className="w-3.5 h-3.5 text-amber-500" />
        <span>700+ Global Builds · 100% On-Time Delivery · 99.8% CSAT</span>
      </div>

      {/* Main Title */}
      <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-[#1E0D36] tracking-tight leading-[1.04]">
        LOOKSBAY <br />
        <span className="bg-gradient-to-r from-[#7C3AED] via-[#9333EA] to-[#4F46E5] bg-clip-text text-transparent">
          Selected Works
        </span>
      </h1>

      {/* Subtitle */}
      <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed font-medium">
        Explore our curated flagship builds featuring custom liquid development, headless CMS architecture, and ultra-high conversion funnels. Scroll down to experience our stacked card showcase.
      </p>

      {/* DYNAMIC CATEGORY PILL FILTER */}
      <div className="flex flex-wrap justify-center gap-2 pt-4">
        {workCategories.map((cat) => {
          const isActive = activeCategory === cat;
          const count =
            cat === "All"
              ? workProjectsList.length
              : workProjectsList.filter((p) => p.category === cat).length;

          return (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all shadow-xs flex items-center gap-2 ${
                isActive
                  ? "bg-[#2E1065] text-white shadow-md scale-105 ring-2 ring-[#CCFF00]"
                  : "bg-white text-slate-700 hover:text-black hover:bg-slate-100 border border-slate-200/80"
              }`}
            >
              <span>{cat}</span>
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  isActive ? "bg-[#CCFF00] text-black font-extrabold" : "bg-slate-100 text-slate-500"
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Parallax Stacking Instruction Hint */}
      <div className="pt-2 flex items-center justify-center gap-2 text-xs font-bold text-purple-700/80">
        <Layers className="w-3.5 h-3.5 text-purple-600 animate-bounce" />
        <span>Scroll down to experience the stacked card parallax effect</span>
      </div>
    </section>
  );
}
