"use client";

import React from "react";
import { Sparkles } from "lucide-react";

/**
 * 📩 Contact Component 1: Hero Header
 * "Let's Build Your Flagship Website" headline & 2-hour turnaround badge
 */
export default function Contact1_Hero() {
  return (
    <section className="text-center max-w-3xl mx-auto space-y-6">
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-100 border border-purple-200 text-purple-900 text-xs font-bold shadow-xs">
        <Sparkles className="w-3.5 h-3.5 text-purple-700" />
        <span>Direct Project Consultation · 2-Hour Response Time</span>
      </div>

      <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-[#1E0D36] tracking-tight leading-[1.05]">
        Let&apos;s Build Your <br />
        <span className="bg-gradient-to-r from-[#7C3AED] via-[#9333EA] to-[#4F46E5] bg-clip-text text-transparent">
          Flagship Website.
        </span>
      </h1>

      <p className="text-base sm:text-lg text-slate-600 max-w-xl mx-auto leading-relaxed font-medium">
        Submit your project details below. Our senior engineering architects will review your brief and respond within 2 business hours.
      </p>
    </section>
  );
}
