import type { Metadata } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  variable: "--font-plus-jakarta",
  display: "swap",
});

export const metadata: Metadata = {
  title: "LOOKSBAY — Web Design & Development Agency",
  description: "We craft high-converting websites across all CMS platforms. WordPress, Shopify, Webflow, Framer & more. 20-person dedicated in-house engineering squad.",
  keywords: "web design agency, shopify development, webflow, wordpress, SEO, CMS development",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`scroll-smooth ${plusJakarta.variable}`}>
      <body className="bg-white text-slate-900 min-h-screen flex flex-col antialiased selection:bg-[#9D5CFF] selection:text-white font-sans" style={{ fontFamily: "var(--font-plus-jakarta), -apple-system, BlinkMacSystemFont, sans-serif" }}>
        <Navbar />
        <main className="flex-grow flex flex-col">
          {children}
        </main>
      </body>
    </html>
  );
}
